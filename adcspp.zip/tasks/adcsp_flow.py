"""TFRecord-backed AdCSPP behavior training and prediction tasks."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping

import tensorflow as tf

from inputs.adcsp.tfrecord_adapter import AdCSPPTFRecordAdapter, batch_size
from models.adcsp.state import UserStateBuilder
from models.adcsp.model import AdCSPPModel
from models.adcsp.generator import AdCSPPPathGenerator
from models.adcsp.flow_prior import AdCSPPFlowPrior
from utils import global_variables as gv
from utils.easydict import EasyDict
from .abstract_task import AbstractTask


def _root_config() -> Mapping[str, Any]:
    return getattr(gv, "TOTAL_CONFIG", {}) or {}


class _AdCSPPTaskBase(AbstractTask):
    self_managed = False
    uses_custom_model = True

    def __init__(self, cfg: EasyDict | None = None):
        self.cfg = cfg or EasyDict()
        self.result = None

    def _config(self, name: str, default=None):
        if name in self.cfg:
            return self.cfg.get(name)
        return _root_config().get(name, default)

    def _model(self) -> AdCSPPModel:
        model_cfg = self._config("model", {}) or {}
        return AdCSPPModel(
            latent_dim=int(model_cfg.get("latent_dim", 16)),
            static_dim=int(model_cfg.get("static_dim", 16)),
            context_dim=int(model_cfg.get("context_dim", 16)),
            hidden_dim=int(model_cfg.get("hidden_dim", 32)),
            seed=int(model_cfg.get("seed", 42)),
            feature_config=model_cfg.get("feature_schema", model_cfg.get("feature_config", {})),
        )

    def _adapter(self) -> AdCSPPTFRecordAdapter:
        model_cfg = self._config("model", {}) or {}
        mapping = dict(model_cfg.get("feature_mapping", {}) or {})
        schema = model_cfg.get("feature_schema", {}) or {}
        if schema.get("user_id_field"):
            mapping["user_id"] = schema["user_id_field"]
        if schema.get("labels"):
            mapping["labels"] = dict(schema["labels"])
        if schema.get("sequence_fields"):
            mapping["sequence"] = {name: name for name in schema["sequence_fields"]}
        return AdCSPPTFRecordAdapter(mapping, schema)

    @staticmethod
    def _restore(model: AdCSPPModel, checkpoint_path: str | None) -> None:
        if checkpoint_path and Path(checkpoint_path).exists():
            model.load_weights(checkpoint_path)


class AdCSPPFlowTrainTask(_AdCSPPTaskBase):
    """Train click and post-click conversion behavior from platform TFRecords."""

    step = "train"

    def run(self) -> None:
        if self.train_dataset is None:
            raise ValueError("AdCSPPFlowTrainTask requires the platform train_dataset")
        model_cfg = self._config("model", {}) or {}
        model = self._model()
        adapter = self._adapter()
        optimizer = tf.keras.optimizers.Adam(learning_rate=float(self.cfg.get("learning_rate", model_cfg.get("learning_rate", 1e-3))))
        conversion_weight = float(self.cfg.get("conversion_loss_weight", 2.0))
        click_window = int(self.cfg.get("click_window_seconds", 30))
        conversion_window = int(self.cfg.get("conversion_window_seconds", 3600))
        epochs = int(self.cfg.get("epochs", 1))
        last_metrics = {}
        first_example = None

        examples = []
        for batch in self.train_dataset:
            features, labels = batch[:2]
            for index in range(batch_size(features, labels)):
                example = adapter.example(
                    features,
                    labels,
                    index,
                    latent_dim=int(model_cfg.get("latent_dim", 16)),
                    feature_config=model_cfg.get("feature_schema", model_cfg.get("feature_config", {})),
                )
                if first_example is None:
                    first_example = example
                examples.append(example)
        if not examples:
            raise ValueError("AdCSPPFlowTrainTask received an empty train dataset")

        grouped = {}
        for example in examples:
            grouped.setdefault(example.state.user_id, []).append(example)
        for user_examples in grouped.values():
            user_examples.sort(key=lambda item: item.context.event_timestamp)

        checkpoint_path = self.cfg.get(
            "checkpoint_path",
            model_cfg.get("checkpoint_path", "checkpoints/adcsp_model.weights.h5"),
        )
        prior_path = self.cfg.get(
            "flow_prior_path",
            model_cfg.get("flow_prior_path", str(Path(checkpoint_path).with_name("adcsp_flow_prior.json"))),
        )
        flow_prior = AdCSPPFlowPrior.fit(examples, seed=int(model_cfg.get("seed", 42)))
        flow_prior.save(prior_path)

        for _ in range(epochs):
            with tf.GradientTape() as tape:
                click_probabilities, conversion_probabilities = [], []
                click_labels, conversion_labels = [], []
                # Carry a differentiable latent state through each user's
                # chronological path.  This makes the transition network
                # learn from future click/conversion supervision instead of
                # being a random post-processing component.
                for user_examples in grouped.values():
                    latent = tf.convert_to_tensor(user_examples[0].state.latent_state, dtype=tf.float32)
                    for example in user_examples:
                        click_probability, conversion_probability = model.differentiable_probabilities(
                            example.state,
                            example.context,
                            click_window,
                            conversion_window,
                            latent_state=latent,
                        )
                        click_probabilities.append(tf.reshape(click_probability, []))
                        conversion_probabilities.append(tf.reshape(conversion_probability, []))
                        click_labels.append(example.is_click)
                        conversion_labels.append(example.is_conversion)
                        latent = model.differentiable_transition(
                            latent,
                            example.state,
                            example.context,
                            example.is_click,
                            example.is_conversion,
                        )

                click_probability = tf.stack(click_probabilities)
                conversion_probability = tf.stack(conversion_probabilities)
                click_label = tf.convert_to_tensor(click_labels, dtype=tf.float32)
                conversion_label = tf.convert_to_tensor(conversion_labels, dtype=tf.float32)
                click_loss = tf.reduce_mean(tf.keras.losses.binary_crossentropy(click_label, click_probability))
                conversion_element_loss = tf.keras.losses.binary_crossentropy(conversion_label, conversion_probability)
                click_mask = tf.stop_gradient(click_label)
                conversion_loss = tf.reduce_sum(conversion_element_loss * click_mask) / tf.maximum(tf.reduce_sum(click_mask), 1.0)
                total_loss = click_loss + conversion_weight * conversion_loss

            gradients = tape.gradient(total_loss, model.trainable_variables)
            optimizer.apply_gradients((gradient, variable) for gradient, variable in zip(gradients, model.trainable_variables) if gradient is not None)
            last_metrics = {"loss": float(total_loss.numpy()), "click_loss": float(click_loss.numpy()), "conversion_loss": float(conversion_loss.numpy())}

        # Build the transition network too.  Otherwise a checkpoint trained
        # only on row-wise behavior losses would silently restore without the
        # state-transition variables used by path generation.
        if first_example is not None:
            model.transition_state(first_example.state, first_example.context, 0, 0, first_example.context.event_timestamp)
        checkpoint = Path(checkpoint_path)
        checkpoint.parent.mkdir(parents=True, exist_ok=True)
        model.built = True
        model.save_weights(str(checkpoint))
        self.result = {"checkpoint_path": str(checkpoint), "flow_prior_path": str(prior_path), **last_metrics}
        logging.info("AdCSPP behavior training finished: %s", self.result)


class AdCSPPSyntheticTrainTask(AdCSPPFlowTrainTask):
    """Offline-only training task backed by the logical trajectory fixture."""

    step = "synthetic_train"
    self_managed = True
    uses_custom_model = True

    def run(self) -> None:
        from inputs.adcsp.synthetic_trajectory import SyntheticTrajectoryConfig, SyntheticTrajectoryGenerator

        synthetic = self.cfg.get("synthetic", {}) or {}
        config = SyntheticTrajectoryConfig(
            num_users=int(synthetic.get("num_users", 32)),
            exposures_per_user=int(synthetic.get("exposures_per_user", 8)),
            sequence_length=int(synthetic.get("sequence_length", 20)),
            seed=int(synthetic.get("seed", 7)),
            start_timestamp=int(synthetic.get("start_timestamp", 1_700_000_000)),
            exposure_gap_seconds=int(synthetic.get("exposure_gap_seconds", 300)),
        )
        self.train_dataset = SyntheticTrajectoryGenerator(config).as_dataset(
            batch_size=int(synthetic.get("batch_size", 32))
        )
        super().run()


class AdCSPPFlowPredictTask(_AdCSPPTaskBase):
    """Predict click and conversion behavior from platform test TFRecords."""

    step = "predict"

    def run(self) -> None:
        if self.test_dataset is None:
            raise ValueError("AdCSPPFlowPredictTask requires the platform test_dataset")
        model_cfg = self._config("model", {}) or {}
        model = self._model()
        adapter = self._adapter()
        click_window = int(self.cfg.get("click_window_seconds", 30))
        conversion_window = int(self.cfg.get("conversion_window_seconds", 3600))
        outputs = {"pred_click_probability": [], "pred_conversion_probability": []}
        restored = False
        for batch in self.test_dataset:
            features, labels = batch[:2]
            for index in range(batch_size(features, labels)):
                example = adapter.example(features, labels, index, latent_dim=int(model_cfg.get("latent_dim", 16)), feature_config=model_cfg.get("feature_schema", model_cfg.get("feature_config", {})))
                if not restored:
                    # Build all Keras variables before restoring the checkpoint.
                    model.differentiable_probabilities(example.state, example.context, click_window, conversion_window)
                    model.built = True
                    self._restore(model, self.cfg.get("checkpoint_path", model_cfg.get("checkpoint_path")))
                    restored = True
                outputs["pred_click_probability"].append(model.click_probability(example.state, example.context, click_window))
                outputs["pred_conversion_probability"].append(model.conversion_probability(example.state, example.context, conversion_window))
        self.results = outputs
        self.result = {"record_count": len(outputs["pred_click_probability"]), "outputs": outputs}
        logging.info("AdCSPP behavior prediction finished: %d records", self.result["record_count"])


class AdCSPPFlowGenerateTask(_AdCSPPTaskBase):
    """Generate continuous user paths from real platform request contexts.

    The platform still supplies TFRecord features.  This task does not create
    or serialize JSON and does not choose an ad: it rolls the trained behavior
    model over the request contexts already present in the input stream,
    samples click/conversion events, and feeds each event into the next state.
    """

    step = "generate"
    self_managed = False
    uses_custom_model = True

    def run(self) -> None:
        dataset = getattr(self, "generate_dataset", None)
        if dataset is None:
            dataset = getattr(self, "test_dataset", None)
        prior_only = bool(self.cfg.get("generate_from_prior", False))
        if dataset is None and not prior_only:
            raise ValueError("AdCSPPFlowGenerateTask requires the platform generation/test dataset")

        model_cfg = self._config("model", {}) or {}
        model = self._model()
        adapter = self._adapter()
        click_window = int(self.cfg.get("click_window_seconds", 30))
        conversion_window = int(self.cfg.get("conversion_window_seconds", 3600))
        generator = AdCSPPPathGenerator(
            model,
            click_window_seconds=click_window,
            conversion_window_seconds=conversion_window,
            max_sequence_length=int(self.cfg.get("max_sequence_length", 20)),
            seed=int(self.cfg.get("seed", model_cfg.get("seed", 42))),
        )
        checkpoint_path = self.cfg.get(
            "checkpoint_path",
            model_cfg.get("checkpoint_path", "checkpoints/adcsp_model.weights.h5"),
        )
        prior_path = self.cfg.get(
            "flow_prior_path",
            model_cfg.get("flow_prior_path", str(Path(checkpoint_path).with_name("adcsp_flow_prior.json"))),
        )
        flow_prior = AdCSPPFlowPrior.load(prior_path) if bool(self.cfg.get("generate_new_contexts", False)) else None

        if dataset is None and prior_only:
            # Fully synthetic mode still requires the learned prior produced
            # by the training task.  There is deliberately no hand-written
            # feature fallback here.
            flow_prior = AdCSPPFlowPrior.load(prior_path)
            seed_profile = flow_prior.sample_profile()
            seed_state = UserStateBuilder.build(seed_profile, latent_dim=int(model_cfg.get("latent_dim", 16)))
            seed_context = flow_prior.sample_context(seed_profile, int(self.cfg.get("start_timestamp", 1)))
            model.differentiable_probabilities(seed_state, seed_context, click_window, conversion_window)
            model.transition_state(seed_state, seed_context, 0, 0, seed_context.event_timestamp)
            model.built = True
            self._restore(model, checkpoint_path)
            generated = []
            for index in range(int(self.cfg.get("num_users", 1))):
                profile = flow_prior.sample_profile(user_id=f"generated_user_{index}")
                state = UserStateBuilder.build(profile, latent_dim=int(model_cfg.get("latent_dim", 16)))
                steps = generator.generate(
                    state=state,
                    prior=flow_prior,
                    num_steps=int(self.cfg.get("num_steps", 8)),
                    start_timestamp=int(self.cfg.get("start_timestamp", 1)),
                    sample=bool(self.cfg.get("sample", True)),
                )
                generated.extend(step.to_dict() for step in steps)
            self.results = {"trajectories": generated}
            self.result = {"user_count": int(self.cfg.get("num_users", 1)), "step_count": len(generated), "results": self.results}
            return

        # Group the stream by user and use request timestamps to restore the
        # chronological path.  Labels, if present, are intentionally ignored:
        # generation samples outcomes from the trained model.
        grouped = {}
        for batch in dataset:
            features, labels = batch[:2]
            for index in range(batch_size(features, labels)):
                example = adapter.example(
                    features,
                    labels,
                    index,
                    latent_dim=int(model_cfg.get("latent_dim", 16)),
                    feature_config=model_cfg.get("feature_schema", model_cfg.get("feature_config", {})),
                )
                grouped.setdefault(example.state.user_id, []).append(example)

        generated = []
        restored = False
        for user_id, examples in grouped.items():
            examples.sort(key=lambda item: item.context.event_timestamp)
            initial_state = examples[0].state.clone()
            contexts = [item.context for item in examples]
            if not restored and contexts:
                model.differentiable_probabilities(initial_state, contexts[0], click_window, conversion_window)
                model.transition_state(initial_state, contexts[0], 0, 0, contexts[0].event_timestamp)
                model.built = True
                self._restore(model, self.cfg.get("checkpoint_path", model_cfg.get("checkpoint_path")))
                restored = True
            if flow_prior is not None:
                steps = generator.generate(
                    state=initial_state,
                    prior=flow_prior,
                    num_steps=int(self.cfg.get("num_steps", len(contexts) or 8)),
                    start_timestamp=int(contexts[-1].event_timestamp if contexts else initial_state.last_update_timestamp),
                    sample=bool(self.cfg.get("sample", True)),
                )
            else:
                steps = generator.rollout(
                    initial_state,
                    contexts,
                    sample=bool(self.cfg.get("sample", True)),
                )
            generated.extend(step.to_dict() for step in steps)

        self.results = {"trajectories": generated}
        self.result = {
            "user_count": len(grouped),
            "step_count": len(generated),
            "results": self.results,
        }
        logging.info(
            "AdCSPP continuous path generation finished: users=%d steps=%d",
            self.result["user_count"],
            self.result["step_count"],
        )

