"""Model pipeline."""
