"""Neural network definitions."""
